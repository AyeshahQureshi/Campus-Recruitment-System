App Link: https://crsfinalproject.firebaseapp.com/
Admin Email: admin@gmail.com and Password: admin17a

Project Details: https://www.dropbox.com/s/691mnjl89e71b5i/ProjectLevel0.doc?dl=0 
