import * as firebase from 'firebase';
var config = {
    apiKey: "AIzaSyDFuwDlOdtJcAr5w8pwBz9X_MhdoZhLu5M",
    authDomain: "crsfinalproject.firebaseapp.com",
    databaseURL: "https://crsfinalproject.firebaseio.com",
    projectId: "crsfinalproject",
    storageBucket: "crsfinalproject.appspot.com",
    messagingSenderId: "1004918588546"
  };
  firebase.initializeApp(config);